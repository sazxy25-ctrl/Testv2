# Saxzy Mod VIP — iOS source project

This is a starter SwiftUI project, not a signed IPA.

## Included
- Your supplied artwork as the app icon and in-app launch/login artwork
- Saxzy Mod VIP branding
- Local first-run password setup (minimum 8 characters)
- Basic document import, file listing, and iOS share/export sheet
- Deployment target intended: iOS 15.0

## Build
1. Open Xcode on a Mac and create a new iOS App project named `SaxzyModVIP` using SwiftUI.
2. Set the deployment target to iOS 15.0.
3. Replace the generated `ContentView.swift` with the included `ContentView.swift`.
4. Copy the included `Assets.xcassets` into the Xcode project, ensuring “Copy items if needed” is selected.
5. Set a unique Bundle Identifier and select your own Apple development signing team.
6. Build and test on devices running supported iOS versions. Export/archive and sign the IPA using your own credentials.

## Important limitations
- This starter does not reproduce 3105's proprietary internals or patch game files.
- `.3105` patch parsing/applying is not implemented.
- The password gate is a simple local prototype, not production-grade authentication.
- iOS 27.2 beta compatibility cannot be guaranteed until that OS build is available and tested.
- Do not share `.p12`, private keys, provisioning profiles, or passwords in chat.
