# Saxzy Mod VIP — source customization

This source tree is based on the supplied 3105 project and retains its GPL-3.0 license and third-party notices.

## Changes in this customization
- App display name and navigation title changed to **Saxzy Mod VIP**.
- The former Home entry now opens the App Data browser.
- The former Sources entry now opens Patch Projects (Patch Files).
- The former Installed entry now opens the existing Cleaner screen.
- Default highlight color is ice blue; Settings provides seven accent-color choices.
- The support status is displayed as the concise label `Support` when the device passes the project's existing support check.
- No separate app-launch password gate is added. Password protection for encrypted patch packages remains part of the upstream patch format and is distinct from an app login password.

## Important platform limits
The cleaner implementation is the original project's limited cleaner. Its allowlist is restricted to `Library/Caches` and `tmp` inside a validated app container. It is not a whole-iPhone cleaner and cannot clear private data for every installed app through ordinary iOS app permissions.

The App Data browser and patch tools remain subject to iOS sandbox permissions and the original project's supported device/runtime conditions. The word `Support` reflects the source project's own version check; it is not a guarantee that every feature works on every device.

## Build
Open `ThreeOneOSFive.xcodeproj` on macOS with a compatible Xcode version, select the `ThreeOneOSFive` scheme, set your own unique bundle identifier and signing team, then Archive/Export for an installable IPA. This ZIP is source code, not a compiled IPA. No signing certificate or private key is included.
