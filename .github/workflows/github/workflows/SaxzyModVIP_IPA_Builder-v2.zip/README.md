# Saxzy Mod VIP v2 — Neon UI Edition

Upgraded SwiftUI iOS project with 4 selectable Cyber-Neon themes, glassmorphic cards, persistent file storage, search bar, and visible Lock button.

## Themes Included
- **Cyber Cyan** (Neon Cyan + Electric Blue)
- **Crimson VIP** (Neon Red + Ember Orange)
- **Royal Gold** (VIP Gold + Amber)
- **Neon Violet** (Ultraviolet + Ice Blue)

## Build on iPhone (GitHub Actions)
1. Upload `SaxzyModVIP_IPA_Builder-v2.zip` to your GitHub repository.
2. Update `.github/workflows/build-ipa.yml` to unzip `SaxzyModVIP_IPA_Builder-v2.zip` (workflow included inside this ZIP).
3. Download `SaxzyModVIP-v2-unsigned-ipa` from the **Actions** tab and sign in eSign.
